﻿const buttonCyphers = [
    1, 2, 3, 4, 5, 6, 7, 8, 9, 0,'.'
];

const operationCyphers = [
    '-', '+', '/', '*'
];

class Calculator extends React.Component {
    state = {
        calcMemory: "",
        calcInput: "",
        answer: "",
        error: "",
        answerCleared: false
    };

    handleAC = () => {
        this.setState({
            calcInput: "",
            calcMemory: "",
            answer: ""
        });
    }

    handleCE = () => {
        this.setState({
            calcInput: "",
            calcMemory: "",
            answer: ""
        });
    }
    backSpace = () => {
        this.setState({
            calcInput: this.state.calcInput.slice(0, -1),
            calcMemory: this.state.calcMemory.slice(0, -1),
            answer: ""
        })
    }

    handleNumberClick = (value) => {
        const shouldShowError = (this.state.calcInput.length >= 10 || this.state.calcMemory.length >= 12);

        switch (true) {
            case shouldShowError === true:
                this.setState({
                    calcInput: "Error",
                    calcMemory: "Error"
                });
                break
            case (this.state.answer !== ""):
                this.setState({
                    answer: "",
                    error: "",
                    calcInput: value,
                    calcMemory: value,
                    answerCleared: true
                });
                return;
            case operationCyphers.includes(this.state.calcInput):
                this.setState({
                    calcInput: value,
                    calcMemory: this.state.calcMemory + value
                });
                break;
            case buttonCyphers.includes(value):
                this.setState({
                    calcInput: `${this.state.calcInput}${value}`,
                    calcMemory: `${this.state.calcMemory}${value}`
                });
                break
        }

    }

    handleOperator = (operator) => {
        const calcm = this.state.calcInput[this.state.calcInput.length - 1];

        switch (true) {
            case (this.state.answerCleared == true):
                //alert("Answer was cleared");
                this.setState({
                    calcInput: operator,
                    calcMemory: this.state.calcMemory + operator
                });
                break

            case operationCyphers.includes(operator):
                this.setState({
                    calcInput: operator,
                    calcMemory: this.state.calcMemory + operator
                });
                break

        }
    }

    handleEqual = (equal) => {
        const answer = eval(this.state.calcMemory);
        this.setState({
            //calcMemory: "= " + parseFloat(answer).toFixed(2),
            calcMemory: "= " + parseFloat(answer),
            calcInput: "",
            answer: answer,
            answerCleared: false
        });

    }

    renderButtons() {
        return buttonCyphers.map((item, index) => (
            <button key={index} onClick={() => this.handleNumberClick(item)}>{item}</button>
        ));
    }
    render() {
        return (
            <div className="calculator">
                <div className="calcpanel">
                    <span className="line" />
                    <span className="camera" />
                </div>
                <div className="_head">
                    <p>{this.state.calcMemory ? this.state.calcMemory : ''}</p>
                    <p className="_display">{this.state.calcInput ? this.state.calcInput : ''}</p>
                    <br/>
                </div>
                <div className="_buttons">
                    <div className="_operators">
                        <button onClick={() => this.handleOperator('+')}>+</button>
                        <button onClick={() => this.handleOperator('-')}>-</button>
                        <button onClick={() => this.handleOperator('*')}>*</button>
                        <button onClick={() => this.handleOperator('/')}>/</button>
                    </div>
                    <br/>
                    <div className="_ACCE">
                        <button onClick={() => this.backSpace()}>DEL</button>

                        <button onClick={() => this.handleCE()}>CE</button>

                    </div>
                    <div className="_numbers">
                        {this.renderButtons()}
                    </div>
                    <br />
                    <div className="Equal">
                        <button onClick={() => this.handleEqual('=')}>=</button>
                    </div>
                </div>
            </div>
        )
    }
}

ReactDOM.render(<Calculator />, document.getElementById('calculator'));