﻿
class Exam extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            subjectKeys: [],
            questions: [],
            questionBank: [],
            answeredQuestions: [],
            currentIndex: -1,
            seconds: 0, // responsible for the seconds
            time: {}, // responsible for the minutes
            intervalSeconds: 0,
            allQuestions: 0,
            showModal: 'none',
            modalInfo: `You can't submit the Exam at this time. Please Continue with the Exam`,
            subjectKey: 0,
            modalHeader: 'Alert',
            allowedQuestionBeforeSubmission: 0,
            allowedTimeBeforeSubmission: 0,
            disableModalBtn: true,
            timeUsed: 0,
            duration: 0,
            showNotificationModal: 'none',
            idleCounter: 0,
            showIdleModal: 'none',
            idleTime: 0,
            cancelButton: 'Ok',
            isSubmitbtnPressed: false,
            answeredQuestiionsNotPushed: [],
            showNetworkModal: 'none',
            disconnectCount: 0,
            hideButton: 'flex',
            remoteIp: null,
            networkModalInfo:null
        };
        this.timer = 0;
        this.timerInterval = null;
        clearInterval(this.timerInterval);
        this.intervalSeconds = 0;
        this.signalRConnection = null;
        this.signalRConnectionCheckConnectivity = null;
       
    }

    componentDidMount() {
        showLoader2();
        
        //this.signalRConnection = new signalR.HubConnectionBuilder()
        //    .withUrl("/comm")
        //    .build();
        //this.signalRConnection.keepAliveIntervalInMilliseconds = 1000 * 60 * 5; // 5 minutes
        //this.signalRConnection.serverTimeoutInMilliseconds = 1000 * 60 * 10; //10 minutes

        //this.signalRConnection.start()
        //    .then(() => {
        //        console.log({ msg: 'React hub connection works' })

        //    });
        this.startSignalRConnection();
        this.startsignalRConnectionCheckConnectivity();
        this.getQuestions();

        document.addEventListener("keydown", this.handleKeyPress);
        //var logoutBtn = document.getElementById("logoutBtn");
        //logoutBtn.setAttribute("href", "#");
        //logoutBtn.onclick = this.endExamBtnClick;
        //logoutBtn.innerHTML = "Submit Exam";
        //clearInterval(this.timerInterval);

        //timerInterval = setInterval(() => this.updateServer(), 30000);
       // timerInterval = setInterval(() => this.closeConnection(), 30000);
        
        var submitbtn = document.getElementById("mainsubmit");
        submitbtn.onclick = this.endExam;
        //Clear local storage if seconds is negative
        let storedSeconds = localStorage.getItem("exam-time");

        let storedUserId = localStorage.getItem("user_Id");
        if (storedSeconds < 0) {
            window.localStorage.clear();
        }
    }
    startSignalRConnection = () => {
        this.signalRConnection = new signalR.HubConnectionBuilder()
            .withUrl("/comm")
            .build();
        this.signalRConnection.serverTimeoutInMilliseconds = 1000 * 60 * 20; //10 minutes
        this.signalRConnection.keepAliveIntervalInMilliseconds = 1000 * 60 * 5; // 5 minutes
      

        this.signalRConnection.start()
            .then(() => {
                this.setState({ disconnectCount: 0 })
                console.log({ msg: 'React hub connection works' })

            });
    }
    //use this to monitor disconnection
    startsignalRConnectionCheckConnectivity = () => {
        this.signalRConnectionCheckConnectivity = new signalR.HubConnectionBuilder()
            .withUrl("/connectivity")
            .build();
        //this.signalRConnectionCheckConnectivity.serverTimeoutInMilliseconds = 1000 * 5; //5 seconds
        //this.signalRConnectionCheckConnectivity.keepAliveIntervalInMilliseconds = 1000 * 3;//3 seconds
        
        this.signalRConnectionCheckConnectivity.start()
            .then(() => {
                this.setState({ disconnectCount:0 })
                console.log({ msg: 'check signalr connection works' })

            });
    }
    closeConnection = () => {
        this.signalRConnection.stop();
    }
    warnUser = (storedSeconds) => {
        if (storedSeconds == 30 || storedSeconds == 60 || storedSeconds == 120 || storedSeconds == 600) {
           /* this.setState({ showModal: 'block', modalInfo: `Your Time Left is: ${this.state.time.h}:${this.state.time.m}:${this.state.time.s}. Submit the Exam Now?`, modalHeader: 'Alert' })*/
            this.setState({
                modalHeader: 'Alert',
                modalInfo: `Your Time Left is: ${this.state.time.h}:${this.state.time.m}:${this.state.time.s}.`, showNotificationModal: 'block', showModal: 'none', cancelButton:'Ok'
            })
            return
        }
        
    }
    //check for idleness
    idleness = (idleSeconds) => {
        if (idleSeconds == this.state.idleTime && this.state.idleTime > 0) {
            this.postTimeStampIfIdle()
            this.setState({
                modalHeader: 'NOT ATTEMPTED ANY QUESTION',
                modalInfo: `Dear Candidate, You have not attempted any question in the past: ${Math.ceil(idleSeconds / 60)} min(s). Kindly contact an administrator for Help if required`, showIdleModal: 'block', showModal: 'none', showNotificationModal:'none'
            })
            return
        }

    }

    componentWillUnmount() {
        document.removeEventListener("keydown", this.handleKeyPress);
    }

    endExamBtnClick = () => {
        this.setState({ isSubmitbtnPressed:true })
        this.setState({ showModal: 'block' })
        this.disableSubmitBtnInModal()
    };
    closeModal = () => {
        this.setState({ isSubmitbtnPressed: false })
        this.setState({ showModal: 'none', showNotificationModal: 'none', showNetworkModal:'none' })
    }
    closeIdleModal = () => {
        this.setState({ isSubmitbtnPressed: false })
        this.setState({ showIdleModal: 'none', showNotificationModal: 'none', showModal: 'none' })
        this.postTimeStampIfIdle()
    }
    closeNetworkAlertModal = () => {
        this.setState({ isSubmitbtnPressed: false })
        this.setState({ showModal: 'none', showNotificationModal: 'none', showNetworkModal: 'none' })
        this.startSignalRConnection();
        this.startsignalRConnectionCheckConnectivity();
    }
    //disableEndExamBtn = () => {
    //    let answeredQuestions = this.state.answeredQuestions
    //    if (answeredQuestions !== null && answeredQuestions !== "" && answeredQuestions !== '[]' && answeredQuestions !== undefined) {
    //        let max = answeredQuestions.length;
    //        console.log("max", max);
    //        if (answeredQuestions.length > 5) {
    //            document.getElementById("logoutBtn").disabled = false;
    //        }
    //        else {
    //            document.getElementById("logoutBtn").disabled = true;
    //        }
    //    }
    //    else {
    //        document.getElementById("logoutBtn").disabled = true;
    //    }
      
    //}
    reconnectSignalRConnection = () => {
        console.log({ msg: 'React hub connection works reconnect' })
        //this.signalRConnection.start()
        //    .then(() => {
        //        console.log({ msg: 'React hub connection works reconnect' })

        //    });
        this.startSignalRConnection();
    }
    startTimer = () => {
        if (this.timer === 0 && this.state.seconds > 0) {
            this.timer = setInterval(this.countDown, 1000);
            let storedSeconds = localStorage.getItem("exam-time");
            let storedUserId = localStorage.getItem("user_Id");
            if (storedSeconds === null) {
                localStorage.setItem("exam-time", this.state.seconds);
                localStorage.setItem("user_Id", this.props.userId);
            }
            if (storedUserId === null && storedSeconds !== null) {
                localStorage.removeItem("exam-time");
                localStorage.removeItem("user_Id");
            }
            if (storedUserId !== this.props.userId && storedUserId !== null) {
                localStorage.removeItem("exam-time");
                localStorage.removeItem("user_Id");
            }
        } else {
            this.timer = setInterval(this.countDown, this.props.timeRemaining);
        }
    };

    secondsToTime = (secs) => {
        let hours = Math.floor(secs / (60 * 60));

        let divisor_for_minutes = secs % (60 * 60);
        let minutes = Math.floor(divisor_for_minutes / 60);

        let divisor_for_seconds = divisor_for_minutes % 60;
        let seconds = Math.ceil(divisor_for_seconds);

        let obj = {
            h: hours,
            m: minutes,
            s: seconds
        };
        return obj;
    };

    disableSubmitBtnInModal = () => {
        if ((this.state.timeUsed < this.state.allowedTimeBeforeSubmission) || !this.checkQuestionsAnswered()) {
            this.setState({
                disableModalBtn: true, modalHeader: 'Alert', isSubmitbtnPressed:false,
                modalInfo: `You can't submit the Exam at this time. You can only submit after ${Math.ceil(this.state.allowedTimeBeforeSubmission / 60)} minutes  and after you have answered ${this.state.allowedQuestionBeforeSubmission} questions in each subject. Please Continue with the Exam`, cancelButton: 'Ok'
            })
            return
        }
        this.setState({ disableModalBtn: false, modalHeader: 'End Examination', modalInfo: `Dear Candidate, you are about to end your exam.`, cancelButton: 'Continue Exam' })
    }

    checkQuestionsAnswered = () => {
        const answeredQuestiions = [...this.state.answeredQuestions]
        let canSubmitExam = true
        for (let key of this.state.subjectKeys) {
            let answeredQuestionsCount = answeredQuestiions.filter((aq) => aq.subjectId === key).length
            if (answeredQuestionsCount < this.state.allowedQuestionBeforeSubmission) {
                canSubmitExam = false
                return canSubmitExam
            } 
        }
        return canSubmitExam
    }

    countDown = () => {
        //check for network connection
        this.checkForConnection()
        // Remove one second, set state so a re-render happens.
        let storedseconds = localStorage.getItem("exam-time");

        if (storedseconds === 0) {
            this.submitExam()
            return
        }
        let duration = this.state.duration;
        if (duration !== undefined && duration > 0) {
            this.setState({
                timeUsed: duration - storedseconds
            })
        }
        else {
            this.setState({
                timeUsed: this.state.timeUsed + 1
            })
        }
        //if (this.state.answeredQuestiionsNotPushed.length > 0) {
        //    this.pushAnswersFromAnsPoll()
        //}
        //else {
        //    const answersNotPushedFromCatch = sessionStorage.getItem("answersNotPushed");
        //    if (answersNotPushedFromCatch !== null && answersNotPushedFromCatch !== "") {
        //        this.setState({
        //            answeredQuestiionsNotPushed: JSON.parse(answersNotPushedFromCatch)
        //        })
        //        if (this.state.answeredQuestiionsNotPushed.length > 0) {
        //            this.pushAnswersFromAnsPoll()
        //        }
                
        //    }
            
            
        //}

        //console.log("notpushcount",this.state.answeredQuestiionsNotPushed.length)
       
        
        //if (storedseconds != null && storedseconds > 0) {
        let seconds = storedseconds - 1;
        this.setState({
            time: this.secondsToTime(seconds),
            seconds: seconds,
        });
        
        this.setState({ idleCounter: this.state.idleCounter + 1 })
        this.intervalSeconds = seconds;
        localStorage.setItem("exam-time", seconds);
        localStorage.setItem("user_Id", this.props.userId);
        //}
        //else {
        //    let seconds = this.state.seconds - 1;
        //    this.setState({
        //        time: this.secondsToTime(seconds),
        //        seconds: seconds,
        //    });
        //}

        //intervalSeconds = seconds;

        
        this.warnUser(storedseconds)
        this.idleness(this.state.idleCounter)
        // Check if we're at zero.
        if (seconds === 0) {
            clearInterval(this.timer);
            window.localStorage.clear();
            this.submitExam();
        }

        const time = `Time Left: ${this.state.time.h} : ${this.state.time.m} : ${this.state.time.s}`;
        //var timeBtn = document.getElementById("timeBtn");
       // timeBtn.innerHTML = time;
    };

    resetTime = () => {
      
        const time = `Time Left: $ 00 : $ 00 : $ 00`;
    };
    getData(url) {
        return new Promise((resolve, reject) => {
            axios.get(url)
                .then((response) => {
                    resolve(response.data);
                    
                })
                .catch((error) => {
                    reject(error);
                });
        });
    }


    getQuestions() {
        const user = sessionStorage.getItem("jamb-user");
        const timer = sessionStorage.getItem("exam-time");
        const cachedHits = sessionStorage.getItem("answers");
        //console.log({ msg: this.props.userId })
        //console.log({ msg2: cachedHits })
        if (user === this.props.userId && cachedHits !== null && cachedHits!=="") {
            this.setState({
                answeredQuestions: JSON.parse(cachedHits),
                seconds: JSON.parse(timer),
                currentIndex: 0,
                subjectKey: 0
            });
        } else {
            sessionStorage.setItem("jamb-user", JSON.parse(this.props.userId));
            sessionStorage.setItem("exam-time", JSON.parse(this.state.seconds));
            sessionStorage.setItem("answers", "");
        }

        //console.log(window.location);
        const API_URL = `/api/ExamAPI/` + this.props.userId;
        this.getData(API_URL).then((responseJson) => {
            //console.log({ getResponse: responseJson })

           //let responseJson=JSON.parse(response)
            if (typeof responseJson !== "undefined") {
                hideLoader2();
                window.localStorage.clear();
                let keys = []
               // console.log("data", responseJson.data);

                const questionsBank = Object.keys(responseJson.data).map((key) => {
                    keys.push(responseJson.data[key].key)
                    return {
                        key: responseJson.data[key].key,
                        questions: responseJson.data[key].questions
                    }
                })

                let allQuestions = 0;
                for (let key in keys) {
                    //allQuestions += responseJson.data[key].length
                    allQuestions += responseJson.data[key].questions.length
                }
                this.setState(
                    {
                        //subjectKeys: keys,
                        subjectKeys: keys,
                        subjectKey: questionsBank[0].key,
                        questionBank: questionsBank,
                        questions: questionsBank[0].questions,
                        currentIndex: 0,
                        seconds:
                            responseJson.timeRemaining > 0
                                ? responseJson.timeRemaining
                                : responseJson.duration * 60,
                        //answeredQuestions: responseJson.ansQues ? responseJson.ansQues : [],
                        answeredQuestions: responseJson.ansQues ? responseJson.ansQues.filter((v, i, a) => a.findIndex(t => (t.id === v.id)) === i)  : [],
                        allQuestions: allQuestions,
                        allowedQuestionBeforeSubmission: responseJson.allowedQuestionBeforeSubmission,
                        allowedTimeBeforeSubmission: responseJson.allowedTimeBeforeSubmission,
                        duration: responseJson.duration * 60,
                        idleTime: responseJson.idleTime,
                        remoteIp: responseJson.remoteIp
                    },
                    () => {
                        //let savedAnswers = this.state.answeredQuestions;
                        this.setState((prevState) => {
                            return { answeredQuestions: prevState.answeredQuestions };
                        });
                        let timeLeftVar = this.secondsToTime(this.state.seconds);
                        this.setState({ time: timeLeftVar });
                        this.startTimer();
                        sessionStorage.setItem("answers", JSON.stringify(this.state.answeredQuestions));
                        sessionStorage.setItem("exam-time", JSON.parse(this.state.seconds));
                        //console.log("duration", this.state.duration)
                        //console.log("filterans", this.state.answeredQuestions.filter((v, i, a) => a.findIndex(t => (t.id === v.id)) === i));
                        //console.log("nonfilterans", this.state.answeredQuestions);
                       
                        
                    }
                );
            }
        })
            .catch((e) => {
                console.log(e);
            });;

        //getData(API_URL).then((response) => {
        //    console.log({ response });
        //});
        //console.log({ rpt })
        //fetch(API_URL)
        //    .then((response) => {
        //    console.log(response)
        //    return response.json()
        //    })
        //    .then((responseJson) => {
        //        console.log({ responseJson })
        //        if (typeof responseJson !== "undefined") {
        //            const keys = Object.keys(responseJson.data);
        //            console.log("data", responseJson.data);
        //            this.setState(
        //                {
        //                    subjectKeys: keys,
        //                    questionBank: responseJson.data,
        //                    questions: responseJson.data[keys[0]],
        //                    currentIndex: 0,
        //                    seconds:
        //                        responseJson.timeRemaining > 0
        //                            ? responseJson.timeRemaining
        //                            : responseJson.duration * 60,
        //                    answeredQuestions: responseJson.ansQues ? responseJson.ansQues : [],
        //                },
        //                () => {
        //                    //let savedAnswers = this.state.answeredQuestions;
        //                    this.setState((prevState) => {
        //                        return { answeredQuestions: prevState.answeredQuestions };
        //                    });
        //                    let timeLeftVar = this.secondsToTime(this.state.seconds);
        //                    this.setState({ time: timeLeftVar });
        //                    this.startTimer();
        //                    console.log("answeredQues", this.state.answeredQuestions);
        //                    sessionStorage.setItem("answers", this.state.answeredQuestions);
        //                    setItem("exam-time", JSON.parse(this.state.seconds));
        //                }
        //            );
        //        }
               
        //    })
        //    .catch((e) => {
        //        console.log(e);
        //    });
    }

    

    loadSubject(key, currentIndex) {
        const user = sessionStorage.getItem("jamb-user");
        const cachedHits = sessionStorage.getItem("answers");
        if (user === this.props.userId && cachedHits) {
            if (this.state.answeredQuestions === []) {
                this.setState({ answeredQuestions: JSON.parse(cachedHits) });
            }
            
        } else {
            sessionStorage.setItem("jamb-user", JSON.parse(this.props.userId));
            sessionStorage.setItem("answers", "");
        }

       // console.log(this.state.answeredQuestions, 'answeredQuestions')

        let ques = this.state.questionBank.find(q => q.key === key)
       

        this.setState({
            questions: ques.questions,
            currentIndex: currentIndex,
            subjectKey: key
        });
    }

    handleKeyPress = (event) => {
        //Arrow Forward
        if (event.keyCode === 39) {
            this.moveForwad();
        }

        //Arrow Forward
        if (event.keyCode === 78) {
            this.moveForwad();
        }

        //Arrow Backward
        if (event.keyCode === 37) {
            this.moveBackward();
        }

        //Arrow Backward
        if (event.keyCode === 80) {
            this.moveBackward();
        }

        //A key
        if (event.keyCode === 65) {
            this.selectA();
        }

        //B key
        if (event.keyCode === 66) {
            this.selectB();
        }

        //C key
        if (event.keyCode === 67) {
            this.selectC();
        }

        //D key
        if (event.keyCode === 68) {
            this.selectD();
        }
        //S key
        if (event.keyCode === 83) {
            this.endExamBtnClick();
        }
        //Y key
        if (event.keyCode === 89) {
            if (this.state.isSubmitbtnPressed) {
                this.endExam();
                //this.webSocketEndExam();
            }
            
        }
        if (event.keyCode === 82) {
            if (this.state.isSubmitbtnPressed) {
                this.closeModal();
                return;
            }
            if (this.state.showIdleModal === 'block') {
                this.closeIdleModal();
                return;
            }
            if (this.state.showNetworkModal === 'block') {
                this.closeNetworkAlertModal();
                return;
            }
            if (this.state.showNotificationModal === 'block') {
                this.closeModal();
                return;
            }
            if (this.state.showModal === 'block') {
                this.closeModal();
                return;
            }

            
        }
        
    };

    handleRadioChange = () => { };

    selectA() {
        document.getElementById("A").checked = true;
        document.getElementById("B").checked = false;
        document.getElementById("C").checked = false;
        document.getElementById("D").checked = false;
        this.setSeletedAnswer("A");
    }

    selectB() {
        document.getElementById("B").checked = true;
        document.getElementById("A").checked = false;
        document.getElementById("C").checked = false;
        document.getElementById("D").checked = false;
        this.setSeletedAnswer("B");
    }

    selectC() {
        document.getElementById("C").checked = true;
        document.getElementById("A").checked = false;
        document.getElementById("B").checked = false;
        document.getElementById("D").checked = false;
        this.setSeletedAnswer("C");
    }

    selectD() {
        document.getElementById("D").checked = true;
        document.getElementById("A").checked = false;
        document.getElementById("B").checked = false;
        document.getElementById("C").checked = false;
        this.setSeletedAnswer("D");
    }

    updateServer() {
        const data = {
            userId: this.props.userId,
            answers: this.state.answeredQuestions,
            //leftTime: this.state.intervalSeconds,
            leftTime: this.state.seconds,
        };
        if (
            data.answers !== null &&
            data.answers !== undefined &&
            data.answers.length > 0
        ) {
            //console.log('data', data);
            const API_URL = `/api/ExamAPI/AutoPost/`;
            fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })
                .then((response) => response.json())
                .then((responseJson) => {
                    //You have received the json containing time
                    //Set the state to update the time
                    // this.setState({ time: responseJson.timeLeft });
                })
                .catch((e) => {
                    console.log(e);
                });
        }
    }

    setSeletedAnswer(option) {

        //if (this.signalRConnection.state !== this.signalR.HubConnectionState.Connected) {
        //    this.setSeletedAnswerWhenUserNotConnected(option);
        //}

        //this.signalRConnection.onclose(function () {
        //    this.reconnectSignalRConnection();
        //})
        //if (this.signalRConnection.connectionState !== 'connected') {
        //    this.reconnectSignalRConnection();
        //}
        let storedUserId = localStorage.getItem("user_Id");
        //console.log({ payload: { option, questionId: question.id, userId: storedUserId } })


        //console.log("Student_answer", option);
        let question = this.state.questions[this.state.currentIndex];
        if (question !== undefined) {
            question.student_answer = option;
            if (
                !_.find(
                    this.state.answeredQuestions,
                    _.matchesProperty("id", question.id)
                )
            ) {
                sessionStorage.setItem(
                    "answers",
                    JSON.stringify(this.state.answeredQuestions.concat(question))
                );
                this.setState({
                    answeredQuestions: this.state.answeredQuestions.concat(question)
                });
            } else {
                // const answeredQuestions = this.state.answeredQuestions;
                const hasBeenAnswered = _.find(
                    this.state.answeredQuestions,
                    _.matchesProperty("id", question.id)
                );
                let answeredQuestions = this.state.answeredQuestions.filter(
                    (item) => item.id !== hasBeenAnswered.id
                );
                hasBeenAnswered.student_answer = option;

                // console.log('hasbeenA', hasBeenAnswered);
                // console.log('Qs', answeredQuestions);
                // answeredQuestions.concat(hasBeenAnswered)
                this.setState({
                    answeredQuestions: answeredQuestions.concat(hasBeenAnswered)
                });
                sessionStorage.setItem("answers", JSON.stringify(answeredQuestions));
                //signalRFunction(option, question.id,)



            }
        }
       
        this.setSeletedAnswerWhenUserNotConnected(option)
        this.setState({ idleCounter: 0 })
        if (this.state.answeredQuestiionsNotPushed.length > 0) {
            this.pushAllAnswersFromAnsPoll()
        }
        else {
            const answersNotPushedFromCatch = sessionStorage.getItem("answersNotPushed");
            if (answersNotPushedFromCatch !== null && answersNotPushedFromCatch !== "") {
                this.setState({
                    answeredQuestiionsNotPushed: JSON.parse(answersNotPushedFromCatch)
                })
                if (this.state.answeredQuestiionsNotPushed.length > 0) {
                    this.pushAllAnswersFromAnsPoll()
                }

            }

        }
    }
    setSeletedAnswerWhenUserNotConnected(option) {
        let storedUserId = localStorage.getItem("user_Id");
        let question = this.state.questions[this.state.currentIndex];
        //check for question existence first
        if (question != undefined) {
            if (_.find(
                this.state.answeredQuestiionsNotPushed,
                _.matchesProperty("id", question.id)
            )) {
                const hasBeenAnswered = _.find(
                    this.state.answeredQuestiionsNotPushed,
                    _.matchesProperty("id", question.id)
                );
                let answeredQuestions = this.state.answeredQuestiionsNotPushed.filter(
                    (item) => item.id !== hasBeenAnswered.id
                );
                hasBeenAnswered.student_answer = option;
                this.setState({
                    answeredQuestiionsNotPushed: answeredQuestiionsNotPushed.push(hasBeenAnswered)
                });
                sessionStorage.setItem("answersNotPushed", JSON.stringify(answeredQuestions));

            }
            else {
                question.student_answer = option;

                sessionStorage.setItem(
                    "answersNotPushed",
                    JSON.stringify(this.state.answeredQuestiionsNotPushed.concat(question))
                );
                this.setState({
                    answeredQuestiionsNotPushed: this.state.answeredQuestiionsNotPushed.push(question),
                });
            }
        }
       
       


        //if (
        //    !_.find(
        //        this.state.answeredQuestiionsNotPushed,
        //        _.matchesProperty("id", question.id)
        //    )
        //) {
        //    sessionStorage.setItem(
        //        "answersNotPushed",
        //        JSON.stringify(this.state.answeredQuestiionsNotPushed.concat(question))
        //    );
        //    this.setState({
        //        answeredQuestiionsNotPushed: this.state.answeredQuestiionsNotPushed.concat(question),
        //    });
        //} else {
        //    const hasBeenAnswered = _.find(
        //        this.state.answeredQuestiionsNotPushed,
        //        _.matchesProperty("id", question.id)
        //    );
        //    let answeredQuestiionsNotPushed = this.state.answeredQuestiionsNotPushed.filter(
        //        (item) => item.id !== hasBeenAnswered.id
        //    );
        //    hasBeenAnswered.student_answer = option;
        //    this.setState({
        //        answeredQuestiionsNotPushed: answeredQuestiionsNotPushed.concat(hasBeenAnswered),
        //    });
        //    sessionStorage.setItem("answersNotPushed", JSON.stringify(answeredQuestiionsNotPushed));



        //}

    }
    postTimeStampIfIdle() {
        this.setState({ idleCounter: 0 })
        let storedUserId = localStorage.getItem("user_Id");
        this.signalRConnection.invoke("SendTimeStamp", {
            
            userId: parseInt(storedUserId),
            timeLeft: this.state.seconds,
        });
    }
    pushAnswersFromAnsPoll() {
        if (this.state.answeredQuestiionsNotPushed.length>0) {
            this.signalRConnection.invoke("SendAnswer", {
                option: this.state.answeredQuestiionsNotPushed[0].student_answer,
                questionId: parseInt(this.state.answeredQuestiionsNotPushed[0].id),
                userId: parseInt(this.props.userId),
                timeLeft: this.state.seconds,
            });
            let currentArray = this.state.answeredQuestiionsNotPushed.slice(1);
            this.setState({
                answeredQuestiionsNotPushed: currentArray
            })
            sessionStorage.setItem("answersNotPushed", JSON.stringify(currentArray));

        }
    }
    pushAllAnswersFromAnsPoll() {
        if (this.state.answeredQuestiionsNotPushed.length > 0) {
            let ctbresponse = [];
            const answeredQuestiionsNotPushedConst = [...this.state.answeredQuestiionsNotPushed]
            //clear this storage once i have collected the items
            sessionStorage.setItem("answersNotPushed", "");
            this.setState({ answeredQuestiionsNotPushed: [] })
            answeredQuestiionsNotPushedConst.map((question, index) => {
                let cbtresponseObj = {
                    option: question.student_answer,
                    questionId: parseInt(question.id),
                    userId: parseInt(this.props.userId),
                    timeLeft: this.state.seconds,
                    remoteIp: this.state.remoteIp
                }
                let cbtresponseObjStr = JSON.stringify(cbtresponseObj)
                ctbresponse.push(cbtresponseObjStr)
            });
            this.signalRConnection.invoke("SendAnswerInBatch", ctbresponse);
           
        }
    }
    //not completed yet
    webSocketEndExam() {
        showEndExam();
        const data = {
            userId: this.props.userId,
            answers: this.state.answeredQuestions,
            leftTime: this.state.seconds,
        };
        let body = JSON.stringify(data);
        //console.log('response', this.state.answeredQuestions);
       // console.log('body', body);
        this.signalRConnection.invoke("EndExamSendAnswer", 
            {
                body
                //userId: this.props.userId,
                //listanswers: JSON.stringify(this.state.answeredQuestions),
                //leftTime: this.state.seconds,
            }

        );
        //localStorage.removeItem("exam-time");
        //localStorage.removeItem("user_Id");
        //localStorage.removeItem("answers");
        //window.localStorage.clear();
        //window.location.href = "/exam/logout";
    }
     
    checkForConnection() {
        if (this.signalRConnectionCheckConnectivity === null || this.signalRConnectionCheckConnectivity.connection.connectionState !== 1) {
            this.setState({
                showModal: 'none', showNotificationModal: 'none', showNetworkModal: 'block', networkModalInfo: `Dear Candidate, your computer has lost connection to the server for ${this.state.disconnectCount + 1} secs. Kindly contact an Administrator for help if required.`, disconnectCount: this.state.disconnectCount + 1, hideButton:'flex'
            })
            if (this.state.disconnectCount > 60 && (this.signalRConnection || this.signalRConnection.connection.connectionState!==1)) {
                this.setState({
                    showModal: 'none', showNotificationModal: 'none', showNetworkModal: 'block', networkModalInfo: `Dear Candidate, your Computer has lost connection to the server for ${this.state.disconnectCount + 1} secs. Kindly contact an Administrator for Help if required.`, disconnectCount: this.state.disconnectCount + 1, hideButton: 'none'
                })
            }
            else {
                return
            }
            
        }
    }
    moveForwad() {
        sessionStorage.setItem("exam-time", JSON.parse(this.state.seconds));
        if ((this.state.currentIndex === this.state.questions.length - 1)) {
            if (this.state.subjectKey === this.state.subjectKeys[this.state.subjectKeys.length - 1]) {
                return
            }
            let newkeyIndex = this.state.subjectKeys.findIndex(q => q === this.state.subjectKey) + 1
            let key = this.state.subjectKeys[newkeyIndex]
            this.setState({ subjectKey: key })
            this.loadSubject(key, 0)
            return
        }
        if (this.state.currentIndex < this.state.questions.length - 1) {
            this.setState({ currentIndex: this.state.currentIndex + 1 });
        }
        
        
    }

    moveBackward() {
        sessionStorage.setItem("exam-time", JSON.parse(this.state.seconds));
        console.log(this.state.subjectKey, this.state.subjectKeys[0])
        if (this.state.subjectKey === this.state.subjectKeys[0] && this.state.currentIndex === 0) {
            return
        }
        if (this.state.currentIndex === 0) {
            let newkeyIndex = this.state.subjectKeys.findIndex(q => q === this.state.subjectKey) - 1
            let key = this.state.subjectKeys[newkeyIndex]

            let curIndex = this.state.questionBank.find(q => q.key === key).questions.length - 1

            //console.log(this.state.subjectKeys, curIndex, key)
          
            
            //console.log(key, 'newKey', curIndex)
            this.setState({ subjectKey: key, currentIndex: curIndex })
            this.loadSubject(key, curIndex)
            return
        }
        if (this.state.currentIndex > 0) {
            this.setState({ currentIndex: this.state.currentIndex - 1 });
        }
    }

    goToQuestion = (questionIndex) => {
        //console.log(questionIndex);
        sessionStorage.setItem("exam-time", JSON.parse(this.state.seconds));
        if (questionIndex <= this.state.questions.length) {
            this.setState({ currentIndex: questionIndex - 1 });
        }
    };

    endExam() {
        showEndExam();
        //resetTime();
        //console.log(this.state.answeredQuestions, 'End Exam Function')
        const data = {
            userId: this.props.userId,
            answers: this.state.answeredQuestiionsNotPushed,
            //answers: this.state.answeredQuestions,
            //leftTime: intervalSeconds,
            //leftTime: this.state.intervalSeconds,
            leftTime: this.state.seconds,
        };
       
        //console.log('data', data);
        const API_URL = `/api/ExamAPI/Post`;
        fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        })
            .then((response) => response.json())
            .then((responseJson) => {
                //document.getElementById('logoutBtn').href = "/exam/logout";
                //document.getElementById('logoutBtn').click();
                localStorage.removeItem("exam-time");
                localStorage.removeItem("user_Id");
                localStorage.removeItem("answers");
                window.localStorage.clear();
                //window.location.href = "/exam/logout";
            })
            .catch((e) => {
                console.log(e);
            });


    }

    //End exam when the time is zero, without showing alert message
    submitExam() {
        const data = {
            userId: this.props.userId,
            //answers: this.state.answeredQuestions,
            answers: this.state.answeredQuestiionsNotPushed,
            //leftTime: intervalSeconds,
            //leftTime: this.state.intervalSeconds,
            leftTime: this.state.seconds,
        };
        localStorage.removeItem("exam-time");
        localStorage.removeItem("user_Id");
        localStorage.removeItem("answers");
        //console.log('data', data);
        const API_URL = `/api/ExamAPI/Post`;
        fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        });
        //window.location.href = "/exam/logout";
        //document.getElementById('endExamByTimer').href = "/exam/logout";
        //document.getElementById('logoutBtn').click();
    }


    render() {
        let options = null;
        let questionCount = null;
        let hasBeenAnswered = null;
        let currentQuestion = {};
        let subjectButtons = null;

        if (this.state.questions && this.state.questions.length > 0) {
            currentQuestion = this.state.questions[this.state.currentIndex];
        }
        if (currentQuestion && currentQuestion.id) {
            hasBeenAnswered = _.find(
                this.state.answeredQuestions,
                _.matchesProperty("id", currentQuestion.id)
            );
        }



        if (currentQuestion && currentQuestion.answers) {
            options = currentQuestion.answers.map((answer) => {
                return (
                    <div key={answer.id} className="radio">
                        <div className="form-group" style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                            <label className="col-sm-2 control-label">
                                {answer.option.toUpperCase()}
                            </label>
                            <div className="col-sm-10 option-div" style={{ margin: '0 auto', paddingTop: "5px"}} >
                                {hasBeenAnswered ? (
                                    <input
                                        style={{ paddingTop: "9px"}}
                                        type="radio"
                                        onChange={this.handleRadioChange}
                                        onClick={() => this.setSeletedAnswer(answer.option)}
                                        id={answer.option}
                                        name="student_answer"
                                        value={answer.optionChoice}
                                        checked={hasBeenAnswered.student_answer === answer.option}
                                    />
                                ) : (
                                        <input
                                            type="radio"
                                            onChange={this.handleRadioChange}
                                            onClick={() => this.setSeletedAnswer(answer.option)}
                                            id={answer.option}
                                            name="student_answer"
                                            value={answer.optionChoice}
                                        />
                                    )}
                                {/*{answer.optionChoice}*/}
                                {HTMLReactParser(answer.optionChoice)}
                                {answer.referenceImage ? (
                                    <img
                                        src={answer.referenceImage}
                                        className="img-responsive question-image"
                                        width="100%"
                                    />
                                ) : null}
                            </div>
                        </div>
                    </div>
                );
            });

            questionCount = this.state.questions.map((question, index) => {
                const hasBeenAnswered = _.find(
                    this.state.answeredQuestions,
                    _.matchesProperty("id", question.id)
                );
                if (hasBeenAnswered) {
                    if (this.state.currentIndex == index) {
                        return (
                            <span
                                key={question.id}
                                onClick={() => this.goToQuestion(index + 1)}
                                className="label label-primary"
                                style={{ margin: "1px", cursor: 'pointer' }}
                            >
                                {index + 1}
                            </span>
                        );
                    }
                    else {
                        return (
                            <span
                                key={question.id}
                                onClick={() => this.goToQuestion(index + 1)}
                                className="label label-success"
                                style={{ margin: "1px", cursor: 'pointer' }}
                            >
                                {index + 1}
                            </span>
                        );
                    }
                  
                } else {
                    if (this.state.currentIndex == index) {
                        return (
                            <span
                                key={question.id}
                                onClick={() => this.goToQuestion(index + 1)}
                                className="label label-primary"
                                style={{ margin: "1px", cursor: 'pointer' }}
                            >
                                {index + 1}
                            </span>
                        );
                    }
                    else {
                        return (
                            <span
                                key={question.id}
                                onClick={() => this.goToQuestion(index + 1)}
                                className="label label-danger"
                                style={{ margin: "1px", cursor: 'pointer' }}
                            >
                                {index + 1}
                            </span>
                        );
                    }
                
                }
            });
            let breakpoint = 5;
            const breakpointInterval = 5;
            questionCount.map((question, index) => {
                if ((index + 1) === breakpoint) {
                    breakpoint += breakpointInterval;
                    return `${question}<br />`

                } else return question;
            });
        }

        subjectButtons = this.state.questionBank.map((q) => {
            const title = q.questions[0].subject.name
            const subjectKey = q.key
            return (
                <button
                    key={subjectKey}
                    onClick={() => this.loadSubject(subjectKey, 0)}
                    className="btn btn-success"
                    style={{ marginLeft: 10, backgroundColor: this.state.subjectKey === subjectKey ? 'green' : '#2b483e'}}
                    type="button"
                >
                    {title}
                </button>
            );
        })

        //subjectButtons = this.state.subjectKeys.map((subject, index) => {
        //    /*const Title = this.state.questionBank[subject][0].subject.name;*/
        //    return (
        //        <button
        //            key={subject}
        //            onClick={() => this.loadSubject(subject, 0)}
        //            className="btn btn-success"
        //            style={{ marginLeft: 10 }}
        //            type="button"
        //        >
        //            Subject name
        //        </button>
        //    );
        //});
        return (
            <div className="">

                <Modal showModal={this.state.showModal} info={this.state.modalInfo} endExam={this.endExam.bind(this)} closeModal={this.closeModal} header={this.state.modalHeader} disabled={this.state.disableModalBtn} cancelButton={this.state.cancelButton} />
                <ModalNotification showNotificationModal={this.state.showNotificationModal} info={this.state.modalInfo} closeModal={this.closeModal} header={this.state.modalHeader} />
                <IdleNessModal showIdleModal={this.state.showIdleModal} info={this.state.modalInfo} closeIdleModal={this.closeIdleModal} header={this.state.modalHeader} />
                <NetworkAlertModal showNetworkModal={this.state.showNetworkModal} closeModal={this.closeNetworkAlertModal} hideButton={this.state.hideButton} info={this.state.networkModalInfo} />
                {this.state.questions && this.state.currentIndex > -1 && currentQuestion?.subject && typeof currentQuestion.subject !== undefined ? (
                    <div className="box">
                        <div className="box-body">
                            <div className="box" style={{ display: 'flex', flexDirection: 'row' }}>{subjectButtons}
                                <div style={{ marginLeft: 'auto', display: 'flex', flexDirection: "row", alignItems: 'center', }}>
                                    <p>Questions Answered{":    "}</p>
                                    <span style={{ color: 'darkgreen', fontSize: '20px', fontWeight: "bold", margin: "0 10px" }}>{this.state.answeredQuestions.filter((v, i, a) => a.findIndex(t => (t.id === v.id)) === i).length} of {this.state.allQuestions}</span>
                                    <div style={{ backgroundColor: "darkgreen", color: "white", borderRadius: '10px', padding: '6px 4px' }}>
                                        <span style={{ fontSize: '20px', fontWeight: 'bold' }}>Time Left: {this.state.time.h}:{this.state.time.m}: {this.state.time.s}</span>
                                    </div>
                                </div>
                                <div style={{ color: 'darkgreen', fontSize: '20px', fontWeight: "bold", margin: "0 10px", padding: '6px 4px' }}>
                                    <button type="button"
                                        onClick={this.endExamBtnClick.bind(this)}
                                        className="btn btn-danger pull-left">
                                        Submit Exam
                                        </button>
                                </div>
                                
                            </div>
                            <h3 className="box-title ">
                                {currentQuestion.subject.name.toUpperCase()}
                            </h3>
                            <form
                                id="frmQuestions"
                                className="form-horizontal"
                                encType="multipart/form-data"
                            >
                                <div className="box box-info">
                                    <div className="box-header with-border">
                                        <h3 className="box-title">
                                            SN. {this.state.currentIndex + 1}
                                        </h3>
                                    </div>
                                    <div
                                        className="box-body"
                                        style={{
                                            fontSize: "medium",
                                            backgroundColor: "rgba(255,255,255,.15)",
                                        }}
                                    >
                                        {currentQuestion.referenceImage ? (
                                            <div className="form-group" style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginRight: '20px' }}>
                                                {/*<label className="col-sm-2 control-label">Reference Image</label>*/}
                                                <div className="col-sm-12" style={{width: '50%'}}>
                                                    <img style={{ width: '100%' }}
                                                        src={currentQuestion.referenceImage}
                                                        //height="100%"
                                                        //width="100%"
                                                    />
                                                </div>
                                            </div>
                                        ) : (
                                                <div className="form-group"></div>
                                            )}
                                        {currentQuestion.referenceText ? (
                                            <div className="form-group" style={{ display: "flex", flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                        {/*                        <label className="col-sm-2 control-label " style={{  padding: "30px"}}>*/}
                        {/*                            Reference Text*/}
                        {/*</label>*/}
                                                <div className="col-sm-12" style={{paddingLeft: '48px', width: "80%" }}>
                                                    <p style={{ height: "auto", textAlign: "justify",  padding: "15px" }}>{HTMLReactParser(currentQuestion.referenceText)}</p>
                                                </div>
                                            </div>
                                        ) : (
                                                <div className="form-group"></div>
                                            )}

                                        <div className="row question-div" style={{  }}>
                                            <label className="col-sm-2 control-label" style={{ fontWeight: "1200", textAlign: 'left'}}>QUESTION.</label>

                                            <label className="col-sm-10 control-label" style={{ textAlign: "left", fontWeight: "normal", marginLeft: '-42px' }}>{HTMLReactParser(currentQuestion.questionText)}</label>
                                            
                                        </div>

                                        {options}
                                    </div>
                                </div>

                                <div>
                                    {this.state.currentIndex > 0 || this.state.subjectKey !== this.state.subjectKeys[0]  ? (
                                        <button
                                            type="button"
                                            onClick={this.moveBackward.bind(this)}
                                            className="btn btn-danger pull-left"
                                        >
                                            Previous{" "}
                                            <i className="glyphicon glyphicon-bold glyphicon-fast-backward  margin-r-10"></i>
                                        </button>
                                    ) : null}
                                    {(this.state.subjectKey !== this.state.subjectKeys[this.state.subjectKeys.length - 1]) || (this.state.currentIndex !== this.state.questions.length -1) ? (
                                        <button
                                            type="button"
                                            onClick={this.moveForwad.bind(this)}
                                            className="btn btn-danger pull-right"
                                        >
                                            Next{" "}
                                            <i className="glyphicon glyphicon-bold glyphicon-fast-forward  margin-r-10"></i>
                                        </button>
                                    )
                                    : null}
                                </div>
                            </form>

                            {
                                <div style={{ display: "flex", flexDirection: "row", justifyContent: "center" }}>
                                    <p style={{ marginLeft: '5px' }}>
                                        
                                        
                                        <cite>
                                            Attempted Questions appear{" "}
                                            
                                            <span className="label label-success">
                                                {" "}
                                                green in color{" "}
                                            </span>
                                        </cite>
                                    </p>
                                    <ul className="fc-color-picker" style={{ display: "flex", flexWrap: "wrap", flexDirection: "row", marginLeft: "12px", maxWidth: "80rem", width: "80%", justifyContent: "left" }}>{questionCount}</ul>
                                </div>
                            }
                        </div>
                    </div>
                ) : null}
            </div>
        );
    }

}

function Modal(props) {
    return (
        <div style={{ display: props.showModal, position: 'fixed', zIndex: '1', left: '0', top: '0', width: '100%', height: '100%', overflow: 'auto', backgroundColor: 'rgba(0,0,0, 0.4)' }}>
            <div style={{ backgroundColor: '#fefefe', margin: '15% auto', padding: '15px', border: '1px solid #888', width: '80%', maxWidth: '60rem', position: 'relative', boxShadow: '0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)' }}>
                <div style={{ display: 'flex', justifyContent: 'center', padding: '10px', width: '100%', backgroundColor: 'darkgreen', color: 'white', margin: '0' }}>
                    <h4>{ props.header }</h4>
                </div>
                <div>
                    <p style={{ padding: '40px 0', fontSize: '18px', fontWeight: 'bold', textAlign: 'center' }} >{ props.info }</p>
                </div>

                <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', marginTop: '65px' }}>
                    <button style={{ marginLeft: 'auto', padding: '6px 8px', width: '80px', marginRight: '15px' }} disabled={props.disabled} className='btn btn-success' onClick={props.endExam.bind(this)}>Yes</button>
                    <button style={{ padding: '6px 8px', width: '110px' }} className="btn btn-danger" onClick={props.closeModal}>{props.cancelButton}</button>
                </div>

            </div>

        </div>
        )
}
function ModalNotification(props) {
    return (
        <div style={{ display: props.showNotificationModal, position: 'fixed', zIndex: '1', left: '0', top: '0', width: '100%', height: '100%', overflow: 'auto', backgroundColor: 'rgba(0,0,0, 0.4)' }}>
            <div style={{ backgroundColor: '#fefefe', margin: '15% auto', padding: '15px', border: '1px solid #888', width: '80%', maxWidth: '60rem', position: 'relative', boxShadow: '0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)' }}>
                <div style={{ display: 'flex', justifyContent: 'center', padding: '10px', width: '100%', backgroundColor: 'darkgreen', color: 'white', margin: '0' }}>
                    <h4>{props.header}</h4>
                </div>
                <div>
                    <p style={{ padding: '40px 0', fontSize: '18px', fontWeight: 'bold', textAlign: 'center' }} >{props.info}</p>
                </div>

                <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', marginTop: '65px' }}>
                   
                    <button style={{ padding: '6px 8px', width: '80px' }} className="btn btn-danger" onClick={props.closeModal}>Close</button>
                </div>

            </div>

        </div>
    )
}
function IdleNessModal(props) {
    return (
        <div style={{ display: props.showIdleModal, position: 'fixed', zIndex: '1', left: '0', top: '0', width: '100%', height: '100%', overflow: 'auto', backgroundColor: 'rgba(0,0,0, 0.4)' }}>
            <div style={{ backgroundColor: '#fefefe', margin: '15% auto', padding: '15px', border: '1px solid #888', width: '80%', maxWidth: '60rem', position: 'relative', boxShadow: '0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)' }}>
                <div style={{ display: 'flex', justifyContent: 'center', padding: '10px', width: '100%', backgroundColor: 'darkgreen', color: 'white', margin: '0' }}>
                    <h4>{props.header}</h4>
                </div>
                <div>
                    <p style={{ padding: '40px 0', fontSize: '18px', fontWeight: 'bold', textAlign: 'center' }} >{props.info}</p>
                </div>

                <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', marginTop: '65px' }}>

                    <button style={{ padding: '6px 8px', width: '80px'}} className="btn btn-danger" onClick={props.closeIdleModal}>Close</button>
                </div>

            </div>

        </div>
    )
}
function NetworkAlertModal(props) {
    return (
        <div style={{ display: props.showNetworkModal, position: 'fixed', zIndex: '1', left: '0', top: '0', width: '100%', height: '100%', overflow: 'auto', backgroundColor: 'rgba(0,0,0, 0.4)' }}>
            <div style={{ backgroundColor: '#fefefe', margin: '15% auto', padding: '15px', border: '1px solid #888', width: '80%', maxWidth: '60rem', position: 'relative', boxShadow: '0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)' }}>
                <div style={{ display: 'flex', justifyContent: 'center', padding: '10px', width: '100%', backgroundColor: 'red', color: 'white', margin: '0' }}>
                    <h4>Network Alert</h4>
                </div>
                <div>
                    <p style={{ padding: '40px 0', fontSize: '18px', fontWeight: 'bold', textAlign: 'center' }} >{props.info}</p>
                </div>

                <div style={{ display: props.hideButton, flexDirection: 'row', alignItems: 'center', marginTop: '65px' }}>

                    <button style={{ padding: '6px 8px', width: '80px'}} className="btn btn-danger" onClick={props.closeModal}>OK</button>
                </div>

            </div>

        </div>
    )
}

if (document.getElementById("exam")) {
    // find element by id
    const element = document.getElementById("exam");

    // create new props object with element's data-attributes
    const props = Object.assign({}, element.dataset);

    // render element with props (using spread)
    ReactDOM.render(<Exam {...props} />, element);
}
