﻿function showLoader2() {
    document.getElementById("spinner-back").classList.add("show");
    document.getElementById("spinner-front").classList.add("show");
    console.log("show loader called")
}
function hideLoader2() {
    document.getElementById("spinner-back").classList.remove("show");
    document.getElementById("spinner-front").classList.remove("show");
    console.log("hide loader called")
}
function showEndExam() {
    document.getElementById("spinner-back").classList.add("show");
    document.getElementById("spinner-EndExams").classList.add("show");
}